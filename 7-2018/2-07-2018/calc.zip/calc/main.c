#include <stdio.h>
#include "common.h"

int main(void)
{
    printf("%d\n", add(5, 3));

    return 0;
}
