int dive(int a, int b)
{
    return a/b;
}
